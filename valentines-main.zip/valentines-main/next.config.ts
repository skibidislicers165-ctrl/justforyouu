import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Your Next.js config
};

export default nextConfig;
